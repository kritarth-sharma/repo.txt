package com.springpacakage.Springcrud.controller;

import com.springpacakage.Springcrud.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
public class EmployeeController {

    public Map<String, Employee> empMap = new HashMap<>();
    public EmployeeController(){
        empMap.put("E101", new Employee("E101","MS","Dhoni",21));
        empMap.put("E102", new Employee("E102","Brett","jain",21));
        empMap.put("E103", new Employee("E103","krish","sharma",21));
    }

    @GetMapping("/employee")
    public String getAllEmployees(Model model){
        model.addAttribute("employees", empMap.values());
        return "employee-list";
    }

    @GetMapping("/employee/add")
    public String addEmployee(){

        return "employee-form";
    }

    @PostMapping("/employee/add")
    public String addEmployee(@ModelAttribute("addEmployee") Employee employee, Model model){
        System.out.println("employee.id "+ employee.getId());
        empMap.put(employee.getId(), employee);
        model.addAttribute("employees", empMap.values());
        return "employee-list";
    }
    @GetMapping("/employee/edit/{id}")
    public String editEmployee(@PathVariable("id") String empId, Model model){
        model.addAttribute("editEmployee", empMap.get(empId));
        return "employee-edit-form";
    }
    @PostMapping("/employee/edit/{id}")
    public String updateEmployee(@PathVariable("id") String empId, @ModelAttribute("editEmployee") Employee employee, Model model){
       System.out.println("employee "+employee.getId());
        System.out.println("employee "+employee.getName());
        System.out.println("employee "+employee.getSurname());
        empMap.put(empId,employee);
        model.addAttribute("employees", empMap.values());
        System.out.println("employees "+employee.getId());
        return "employee-list";
    }

    @GetMapping("/employee/delete/{id}")
    public String deleteEmployee(@PathVariable("id") String empId, Model model){
        empMap.remove(empId);
        model.addAttribute("employees", empMap.values());
        return "employee-list";
    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("editEmployee") Employee employee) {
        //service.save(employee);
        System.out.println("employee " + employee.getId());
        System.out.println("employee " + employee.getAge());
        System.out.println("employee " + employee.getName());
        System.out.println("employee " + employee.getSurname());
        return null;
    }
}
